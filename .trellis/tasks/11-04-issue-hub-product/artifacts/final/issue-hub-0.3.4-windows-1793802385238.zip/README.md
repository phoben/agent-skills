# Issue Hub 0.3.4 Windows验收包

这是本地可转交验收包，尚未正式发布到yg源。预先安装Node 24、Git、gh、Codex，并完成各自gh登录。

先解压到稳定目录；不要在压缩包内直接运行。仅检查环境：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1 -CheckOnly
```

在尚未安装正式Issue Hub的验收电脑安装：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

脚本校验文件和依赖，只注册issue-hub-review临时源，不替换已有yg源。已有正式Issue Hub时拒绝并装；正式分发仍沿用yg，验收版与正式版不要同时启用。解压目录是本地源，安装后保留。

插件主入口只有一个。核对仓库列表、真实正文/评论、草稿恢复；在授权仓库核对写后读回；创建任务应在正确工作区预填但未发送，原草稿保留，手动发送后可核对关联并返回。迁移身份仅兼容可证明的旧scope，不按名称猜认其他会话。

命令行诊断：`node plugins/issue-hub/dist/issue-hub.cjs --doctor`。诊断不发布GitHub内容或发送聊天。包外协议、隔离Codex配置目录不能代替第二台真实Windows验收。

卸载验收入口：`codex plugin remove issue-hub@issue-hub-review`，随后可按团队正式发布说明使用yg源；本机未发布草稿不随卸载自动删除。
